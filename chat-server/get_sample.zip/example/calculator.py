class Calculator:
    def __init__(self, a, opcode, b):
        print(f'utils.py / myRandom() 을 이용하여 자동 랜덤 계산기를 생성합니다')
        print('(ex) 5 + 4 = 9')