from example.utils import myRandom


class Grade:

    def __init__(self) -> None:
        # 아래 주석된 부분을 완성합니다.
        kor = myRandom(0,100)
        eng = myRandom(0, 100)
        math = myRandom(0, 100)
        # sum = self.sum(kor, eng, math)
        # avg = self.agv(kor, eng, math)
        # grade = self.getGrade()
        # passChk = self.passChk()
        # return [sum, avg, grade, passChk]